<?php
include('config.php');

$title = $description = '';
$error_array = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty(trim($_POST["title"]))) {
        $error_array[] = "Please enter a title.";
    } else {
        $title = trim($_POST["title"]);
    }

    if (empty(trim($_POST["description"]))) {
        $error_array[] = "Please enter a description.";
    } else {
        $description = trim($_POST["description"]);
    }

    if (empty($error_array)) {
        $sql = "INSERT INTO recipes (title, description) VALUES ('$title', '$description')";
        if(mysqli_query($conn, $sql)){
          header('Location: index.php');
        } else {
          $error_array[] = 'Query error: '. mysqli_error($conn);
          session_start();
          $_SESSION['errors'] = $error_array;
          header('Location: error.php');
        }
    } else {
      session_start();
      $_SESSION['errors'] = $error_array;
      header('Location: error.php');
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Create Recipe</title>
  <link rel="stylesheet" href="css/navigation.css">
  <link rel="stylesheet" href="css/form_elements.css">
  <link rel="stylesheet" href="css/styles.css">
</head>
<body>
  <?php include('header.php') ?>
  <div class="container">
    <h2>Create Recipe</h2>
    <form class="create-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
      <div>
        <label>Title</label>
        <input type="text" name="title" value="<?php echo $title; ?>">
      </div>
      <div>
        <label>Description</label>
        <textarea name="description"><?php echo $description; ?></textarea>
      </div>
      <div class="create-recipe form-actions">
        <a type="button" class="btn" href="index.php">Cancel</a>
        <input type="submit" value="Submit">
      </div>
    </form>
  </div>
</body>
</html>
