<!--
  Jyoti kaur 
  202107441
-->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Proposal</title>
    <link rel="stylesheet" href="css/navigation.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/proposal.css">
  </head>
  <body>
    <?php include 'header.php'; ?>  
    <main>
      <div>
        <h1>Recipe Management System (RMS)</h1>
        <p>In today's fast-paced world, managing recipes manually can be a difficult task. RMS is a database-driven web application designed to provide a comprehensive solution for managing your recipes. This application aims to automate the process of managing and organizing your recipes, making it more accessible and more secure from accidently losing them.</p>
      </div>
      <hr>
      <div>
        <h2>Features</h2>
        <ul>
          <li>Recipe Management: RMS provides a centralized platform for managing your recipes. You can search for recipes, view recipe details, edit existing recipie, and add your own recipes to the database.</li>
          <li>Ingredient Management: RMS enables you to manage your ingredients efficiently. You can view your upcoming ingredient needs, add new ingredients to your pantry, and track your inventory.</li>
          <li>Meal Planning: RMS allows you to plan your meals based on your ingredient inventory. You can create meal plans, invite your family members, and share your meal plans with them.</li>
          <li>Collaboration Tools: RMS provides collaboration tools that enable you to share your recipes with your family members and friends. You can create groups, invite your family and friends, and share your recipes using the application's built-in tools.</li>
          <li>Notifications and Reminders: RMS sends notifications and reminders to you about your upcoming meals, ingredient needs, and recipe updates.</li>
        </ul>
      </div>
      <hr>
      <div>
        <h2>User Interface</h2>
        <p>The RMS application has a modern and user-friendly interface that provides a seamless user experience. The application's navigation menu is consistent across all pages, making it easy for you to navigate the application. The application's color scheme and typography are designed to be visually appealing and engaging.</p>
      </div>
      <hr>
      <div>
        <h2>Database</h2>
        <p>RMS uses a MySQL database to store all the recipes, ingredients, and user information. The database is designed to be scalable and efficient, ensuring that your recipes and ingredients are stored securely and reliably.</p>
      </div>
      <hr>
    </main>
    <footer>
      <p>&copy; 2024 Recipe Management System (RMS). All rights reserved.</p>
    </footer>
  </body>
</html>