<!--
  Jyoti kaur 
  202107441
-->
<?php
include('config.php');

// Fetch recipes from the database
$sql = "SELECT * FROM recipes";
$result = $conn->query($sql);
$recipes = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Recipe Management System (RMS)</title>
  <link rel="stylesheet" href="css/navigation.css">
  <link rel="stylesheet" href="css/styles.css">
</head>
<body>
  <?php include('header.php') ?>
  <div class="container">
    <h1>Featured Recipes</h1>
    <div class="create-recipe content-right">
      <a type="button" class="btn" href="create.php">New Recipe</a>
    </div>

    <?php if(count($recipes) > 0) { ?>
      <ul class="recipes-list">
        <?php foreach($recipes as $recipe) { ?>
          <li class="recipe-item">
            <div class="details">
              <h3><?php echo $recipe['title']; ?></h3>
              <p>Description: <?php echo $recipe['description']; ?></p>
              <button class="btn"><a style="text-decoration: none; color: #fff;" href="read.php?id=<?php echo $recipe['id']; ?>">Read</a></button>
              <button class="btn"><a style="text-decoration: none; color: #fff;" href="update.php?id=<?php echo $recipe['id']; ?>">Update</a></button>
              <button class="btn"><a style="text-decoration: none; color: #fff;" href="delete.php?id=<?php echo $recipe['id']; ?>">Delete</a></button>
            </div>
            <img src="images/dish-1.jpeg" width="210" style="margin-left: 20px;" alt="Recipe image">
          </li>
        <?php } ?>
      </ul>
    <?php } else { ?>
      <p>No recipes found</p>
    <?php } ?>
  </div>
</body>
</html>

