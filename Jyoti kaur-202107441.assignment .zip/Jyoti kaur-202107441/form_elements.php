<!--
  Jyoti kaur 
  202107441
-->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Elements</title>
    <link rel="stylesheet" href="css/form_elements.css">
    <link rel="stylesheet" href="css/navigation.css">
    <link rel="stylesheet" href="css/styles.css">
  </head>
  <body>
    <?php include 'header.php'; ?>
    <main>
      <h1>Form Elements</h1>
    <form>
      <label for="name">Name:</label>
      <input type="text" id="name" name="name" required>
      <br>
      <label for="name">Number:</label>
      <input type="number" id="number" name="number" required>
      <br>
      <label for="email">Email:</label>
      <input type="email" id="email" name="email" required>
      <br>
      <label for="password">Password:</label>
      <input type="password" id="password" name="password" required>
      <br>
      <label for="dob">Date of Birth:</label>
      <input type="date" id="dob" name="dob" required>
      <br>
      <label for="gender">Gender:</label>
      <select id="gender" name="gender" required>
        <option value="">Select...</option>
        <option value="male">Male</option>
        <option value="female">Female</option>
        <option value="other">Other</option>
      </select>
      <br>
      <label for="terms">Accept Terms and Conditions: (checkbox)</label>
      <input type="checkbox" id="terms" name="terms" required>
      <br>
      <label for="courses">Select Courses:</label>
      <select id="courses" name="courses" required>
        <option value="html">HTML</option>
        <option value="css">CSS</option>
        <option value="js">JavaScript</option>
        <option value="react">React</option>
        <option value="node">Node.js</option>
      </select>
      <br>
      <label for="message">Message:</label>
      <textarea id="message" name="message" rows="4" cols="50" required></textarea>
      <br>
      <label for="file">File:</label>
      <input type="file" id="file" name="file" accept=".txt, .pdf" required>
      <br>
      <label for="color">Color:</label>
      <input type="color" id="color" name="color" value="#ffffff" required>
      <br>
      <input type="submit" value="Submit">
    </form>
    </main>
    <footer>
      <p>&copy; 2024 Recipe Management System (RMS). All rights reserved.</p>
    </footer>
  </body>
</html>