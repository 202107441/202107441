<header>
  <nav>
    <ul>
      <img class="logo" src="images/logo.png" width="50px" alt="RMS">
      <li><a href="index.php">Home</a></li>
      <li><a href="form_elements.php">Form Elements</a></li>
      <li><a href="proposal.php">Proposal</a></li>
    </ul>
  </nav>
</header>
