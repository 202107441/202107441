<header>
  <nav>
    <ul>
      <img class="logo" src="images/logo.png" width="50px" alt="RMS">
      <li><a href="index.php">Home</a></li>
      <li><a href="form_elements.php">Form Elements</a></li>
      <li><a href="proposal.php">Proposal</a></li>
      <li><a href="resources.html">Resources</a></li>
      <li><a href="me.html">About Me</a></li>
    </ul>
  </nav>
</header>
