<?php
include('config.php');

if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
    $recipe_id = trim($_GET["id"]);
    $sql = "SELECT * FROM recipes WHERE id = '$recipe_id'";  
    $result = mysqli_query($conn, $sql);

    if($result->num_rows == 1){
        $row = $result->fetch_assoc();
        $id = $row["id"];
        $title = $row["title"];
        $description = $row["description"];
    } else{
        $error_array[] = "Record can not be found by given ID = '$recipe_id'";
        session_start();
        $_SESSION['errors'] = $error_array;
        header("location: error.php");
        exit();
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if(isset($_POST["id"]) && !empty(trim($_POST["id"]))){
        $id = trim($_POST["id"]);
        $sql = "DELETE FROM recipes WHERE id = '$id'";
    
        if(mysqli_query($conn, $sql)){
          header('Location: index.php');
        } else {
          $error_array[] = 'query error: '. mysqli_error($conn);
          session_start();
          $_SESSION['errors'] = $error_array;
          header('Location: error.php');
        }
    }
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Delete Recipe</title>
  <link rel="stylesheet" href="css/navigation.css">
  <link rel="stylesheet" href="css/styles.css">
  <link rel="stylesheet" href="css/form_style.css">
</head>
<body>
  <?php include('header.php') ?>
  <div class="container">
    <h2>Delete Recipe</h2>
    <div class="recipe-details">
      <h3><?php echo $title; ?></h3>
      <p>Description: <?php echo $description; ?></p>
    </div>
    <b><p>Are you sure you want to delete this recipe?</p></b>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" class="form">
      <input type="hidden" name="id" value="<?php echo trim($_GET["id"]); ?>">
      <a href="index.php" class="btn">Go Back</a>
      <input type="submit" value="Delete" class="btn">
    </form>
  </div>
</body>
</html>
