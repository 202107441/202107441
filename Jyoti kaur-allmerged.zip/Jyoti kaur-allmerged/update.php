<?php
include('config.php');

$title = $description = '';
$title_err = $description_err = '';
$error_array = [];

if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
    $recipe_id = trim($_GET["id"]);
    $sql = "SELECT * FROM recipes WHERE id = '$recipe_id'";  
    $result = mysqli_query($conn, $sql);

    if($result->num_rows == 1){
        $row = $result->fetch_assoc();
        $id = $row["id"];
        $title = $row["title"];
        $description = $row["description"];
    } else{
        $error_array[] = "Record can not be found by given ID = '$recipe_id'";
        session_start();
        $_SESSION['errors'] = $error_array;
        header("location: error.php");
        exit();
    }
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty(trim($_POST["title"]))) {
        $error_array[] = "Please enter a title.";
    } else {
        $title = trim($_POST["title"]);
    }

    if (empty(trim($_POST["description"]))) {
        $error_array[] = "Please enter a description.";
    } else {
        $description = trim($_POST["description"]);
    }

    if (empty($error_array)) {
        $id = trim($_POST["id"]);
        $sql = "UPDATE recipes SET title='$title', description='$description' WHERE id='$id'";

        if(mysqli_query($conn, $sql)){
          header('Location: index.php');
        } else {
          $error_array[] = 'Query error: '. mysqli_error($conn);
          session_start();
          $_SESSION['errors'] = $error_array;
          header('Location: error.php');
        }
    } else {
      session_start();
      $_SESSION['errors'] = $error_array;
      header('Location: error.php');
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Update Recipe</title>
  <link rel="stylesheet" href="css/navigation.css">
  <link rel="stylesheet" href="css/styles.css">
  <link rel="stylesheet" href="css/form_elements.css">
</head>
<body>
  <?php include('header.php') ?>
  <div class="container">
    <h2>Update Recipe</h2>
    <form class="create-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
      <div>
        <label>Title</label>
        <input type="number" name="id" value="<?php echo $id; ?>" hidden>
        <input type="text" name="title" value="<?php echo $title; ?>">
        <span><?php echo $title_err; ?></span>
      </div>
      <div>
        <label>Description</label>
        <textarea name="description"><?php echo $description; ?></textarea>
        <span><?php echo $description_err; ?></span>
      </div>
      <div class="create-recipe form-actions">
        <a type="button" class="btn" href="index.php">Cancel</a>
        <input type="submit" value="Update">
      </div>
    </form>
  </div>
</body>
</html>
