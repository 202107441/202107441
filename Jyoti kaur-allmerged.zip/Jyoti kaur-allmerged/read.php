<?php
include('config.php');

if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
    $recipe_id = trim($_GET["id"]);
    $sql = "SELECT * FROM recipes WHERE id = '$recipe_id'";  
    $result = mysqli_query($conn, $sql);

    if($result->num_rows == 1){
        $row = $result->fetch_assoc();
        $id = $row["id"];
        $title = $row["title"];
        $description = $row["description"];
    } else{
        $error_array[] = "Record can not be found by given ID = '$recipe_id'";
        session_start();
        $_SESSION['errors'] = $error_array;
        header("location: error.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>View Recipe</title>
  <link rel="stylesheet" href="css/navigation.css">
  <link rel="stylesheet" href="css/styles.css">
</head>
<body>
  <?php include('header.php') ?>
  <div class="container">
    <h2>Recipe Details</h2>
    <div class="recipe-item">
      <div class="details">
        <h3><?php echo $title; ?></h3>
        <p>Description: <?php echo $description; ?></p>
        <a class="btn" href="index.php">Homepage</a>
      </div>
      <img src="images/dish-1.jpeg" width="210" style="margin-left: 20px;" alt="Recipe image">
    </div>
  </div>
</body>
</html>
